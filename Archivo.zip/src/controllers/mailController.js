const express = require('express');
const nodeMailer = require('nodemailer');
require ('dotenv').config({path: '.env'})

const app = express();
const bodyParser = require('body-parser');

app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());



 const envioCorreo = (req, res) =>{
    
     let trasporter = nodeMailer.createTransport({
         
         host:'labusqueda182.com',
         post:465,
         
         
        /*service: 'gmail',    */
         auth:{
             user: 'alberto.cabello64@gmail.com',
             pass:'AltMati2308'
         }
     });

     const mailOpciones = {
        from:'Logia',
        to: req.body.email,
        subjet: req.body.asunto,
        text: req.body.mensaje
     };

     trasporter.sendMail(mailOpciones,function(err,res){
        if(err) {
            console.log('aqui')
            console.log(err)
        }else{
            console.log('iii')
            console.log('Correo enviado')
            
        }  
       
     })
    }

    module.exports = {
        envioCorreo
    }
        
